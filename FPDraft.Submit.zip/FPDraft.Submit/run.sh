#!/bin/bash
make
./main
rm main